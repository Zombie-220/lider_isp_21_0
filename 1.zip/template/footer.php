<?php
    function render_footer() {
        echo "
            <footer>
                <p class='footer__p'>&#169;Лидер Денис. 2024 год.</p>
            </footer>
        ";
    }
?>